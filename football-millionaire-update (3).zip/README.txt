1) فك الضغط وارفع كل الملفات على المستودع (نفس الأماكن).
2) ملف www/app.js: لو app.js عندك في فولدر تاني (مش www)، حطه مكان القديم.
3) Settings > Secrets and variables > Actions > New secret: الاسم ANTHROPIC_API_KEY والقيمة مفتاحك.
4) Actions > Add new questions > Run workflow (تجربة أولى).
5) ابنِ التطبيق من جديد وثبّته.
